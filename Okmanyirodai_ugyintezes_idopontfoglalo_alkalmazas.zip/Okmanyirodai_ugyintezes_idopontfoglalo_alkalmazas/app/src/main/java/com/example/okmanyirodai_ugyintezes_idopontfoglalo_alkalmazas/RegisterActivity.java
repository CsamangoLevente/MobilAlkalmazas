package com.example.okmanyirodai_ugyintezes_idopontfoglalo_alkalmazas;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class RegisterActivity extends AppCompatActivity {
    private static final String LOG_TAG = RegisterActivity.class.getName();
    EditText userEmailR, userPasswordR, getUserPasswordReplyR;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_register);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        int secret_key = getIntent().getIntExtra("SECRET_KEY", 0);
        if (secret_key != 99) {
            finish();
        }

        userEmailR = findViewById(R.id.editTextEmailR);
        userPasswordR = findViewById(R.id.editTextPasswordR);
        getUserPasswordReplyR = findViewById(R.id.editTextPasswordRIsm);

        Log.i(LOG_TAG, "onCreate");
    }

    public void Registration(View view) {
        String userEmailStrR = userEmailR.getText().toString();
        String userPasswordStrR = userPasswordR.getText().toString();
        String userPasswordStrReplyR = getUserPasswordReplyR.getText().toString();
        if (!userPasswordStrR.equals(userPasswordStrReplyR)) {
            Log.e(LOG_TAG, "Nem egyenlő a jelszó és annak megismétlése!");
        }
        Log.i(LOG_TAG, "Regisztrált email: " + userEmailStrR + ", Jelszó: " + userPasswordStrR);
    }

    public void Cancel(View view) {
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i(LOG_TAG, "onDestroy");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i(LOG_TAG, "onResume");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i(LOG_TAG, "onStart");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i(LOG_TAG, "onStop");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i(LOG_TAG, "onPause");
    }
}